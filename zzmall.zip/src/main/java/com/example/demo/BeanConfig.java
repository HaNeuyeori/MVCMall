package com.example.demo;

import org.springframework.context.annotation.*;
import org.springframework.security.crypto.bcrypt.*;
import org.springframework.security.crypto.password.*;

@Configuration
public class BeanConfig {
	@Bean
	public PasswordEncoder passwordEncoder() {
		// 비밀번호 암호화에 사용되는 BCrypt의 구현 객체를 스프링에 등록
		return new BCryptPasswordEncoder();
	}
}
