package com.example.demo.controller;

import java.security.*;

import javax.servlet.http.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.scheduling.annotation.*;
import org.springframework.security.access.annotation.*;
import org.springframework.security.access.prepost.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.mvc.support.*;

import com.example.demo.dto.*;
import com.example.demo.service.*;

@Controller
public class MemberController {
	@Autowired
	private MemberService service;

	// 접근 제어(access control) : 권한 확인 -> 실패하면 403
	@PreAuthorize("isAnonymous()")
	@GetMapping("/member/join")
	public void join() {
	}

	@PreAuthorize("isAnonymous()")
	@GetMapping("/member/login")
	public void login() {
	}

	@PreAuthorize("isAnonymous()")
	@GetMapping("/member/find")
	public void find() {
	}

	// J-004. 회원 가입
	@PostMapping("/member/join")
	public ModelAndView join(MemberDto.Join dto) {
		service.join(dto);
		return new ModelAndView("redirect:/member/login");
	}

	@Secured("ROLE_USER")
	@GetMapping("/member/check-password")
	public void checkPassword() {
	}

	// J-005. 비밀번호 확인
	@Secured("ROLE_USER")
	@PostMapping("/member/check-password")
	public ModelAndView checkPassword(String password, Principal principal, HttpSession session,
			RedirectAttributes ra) {
		Boolean result = service.checkPassword(password, principal.getName());
		// 비밀번호가 틀린 경우 RedirectAttributes에 에러 메시지를 저장한 다음 비밀번호 확인으로 다시 이동
		if (result == false) {
			ra.addFlashAttribute("msg", "비밀번호를 확인하지 못했습니다");
			return new ModelAndView("redirect:/member/check-password");
		}
		// 비밀번호가 맞은 경우 세션에 "비밀번호를 확인했다"는 사실을 저장한 다음 내정보 보기로 이동
		session.setAttribute("checkPassword", true);
		return new ModelAndView("redirect:/member/read");
	}

	// J-006. 내정보 보기
	@Secured("ROLE_USER")
	@GetMapping("/member/read")
	public ModelAndView read(Principal principal, HttpSession session) {
		// 비밀번호 확인이 안된 경우 "/member/check-password"로 이동
		if(session.getAttribute("checkPassword") == null)
			return new ModelAndView("redirect:/member/check-password");
		MemberDto.Read dto = service.read(principal.getName());
		return new ModelAndView("member/read").addObject("member", dto);
	}

	// J-007. 이메일 변경
	@Secured("ROLE_USER")
	@PostMapping("/member/change-email")
	public ModelAndView changeEmail(String email, Principal principal) {
		service.changeEmail(email, principal.getName());
		return new ModelAndView("redirect:/member/read");
	}

	// J-008. 회원 탈퇴 : 탈퇴와 로그아웃 함께 진행
	@Secured("ROLE_USER")
	@PostMapping("/member/quit")
	public ModelAndView quit(Principal principal, HttpSession session) {
		session.invalidate();
		service.quit(principal.getName());
		return new ModelAndView("redirect:/");
	}
	
	// J-009. 스프링 스케줄러 : 일정간격 또는 정해진 시간(cron 표기법)에 메소드 실행
	@Scheduled(fixedDelay=10000)
	public void scheduledTask1() {
		System.out.println("10초마다 실행됩니다");
	}
	
	@Scheduled(cron="0 25 14 1/1 * ?")
	public void scheduledTask2() {
		System.out.println("cron식에 따라 실행됩니다");
	}
}
