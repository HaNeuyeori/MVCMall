package com.example.demo.controller;

import java.io.*;
import java.nio.file.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.service.*;

// REST 응답인 경우, 데이터를 출력하는 경우가 아니라면 상태코드가 작업의 결과
//바람직한 결과인 경우 상태 코드 200을 출력
//바람직하지 않은 결과의 경우 상태 코드 409를 출력

@RestController
public class MemberRestController {
	@Autowired
	private MemberService service;
	
	// J-001. 아이디 사용 여부 확인
	@GetMapping("/member/username/available/{username}")
	public ResponseEntity<Void> usernameAvailable(@PathVariable String username) {
		Boolean result = service.usernameAvailable(username);
		return result? ResponseEntity.ok(null): ResponseEntity.status(HttpStatus.CONFLICT).body(null);
	}
	
	// J-002. 아이디 찾기
	@GetMapping(value="/member/username/{email}")
	public ResponseEntity<String> findUsername(@PathVariable String email) {
		String username = service.findUsername(email);
		if(username==null)
			return ResponseEntity.status(HttpStatus.CONFLICT).body("아이디를 찾을 수 없습니다");
		return ResponseEntity.ok(username);
	}
	
	
	// J-003. 이미지 보기
	// - REST 방식으로 파일을 출력할 경우 ResponseEntity<byte[]>
	// - 파일을 전달받은 웹 브라우저는 파일의 종류(ContentType)에 따라 처리 방식을 정한다
	//   웹 브라우저가 알고있는 파일 종류인 경우(윈도우에 파일 형식을 처리할 프로그램이 설치된 경우)
	//     파일이 이미지인 경우 브라우저가 직접 출력한다 
	//     예를 들어 ContentType이 "application/excel"이고 엑셀이 설치된 경우 프로그램을 실행하고 파일을 연다
	//   웹 브라우저가 처리할 수 없는 파일 종류인 경우 다운로드한다
	@GetMapping(value="/profiles/{imageName}")
	public ResponseEntity<byte[]> viewProfile(@PathVariable String imageName) {
	  File file = new File("c:/upload/profile", imageName);
	  try {
		// 1. 파일을 byte[]로 변환
		byte[] bytes = Files.readAllBytes(file.toPath());
		// 2. 파일의 ContentType을 읽어온다(이미지이므로 대충 "image/jpg" 또는 "image/png")
		String contentType = Files.probeContentType(file.toPath()); 
		// 3. 문자열인 ContentType을 스프링이 정의해 놓은 enum으로 변환한다
		MediaType type = MediaType.parseMediaType(contentType);
		// byte[]인 파일과 그 파일의 ContentType enum을 ResponseEntity로 출력한다
		return ResponseEntity.ok().contentType(type).body(bytes);
	  } catch(Exception e) {
		  e.printStackTrace();
	  }
	  return null;
	}
}








