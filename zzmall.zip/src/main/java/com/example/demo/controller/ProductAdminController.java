package com.example.demo.controller;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.access.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

import com.example.demo.dto.*;
import com.example.demo.service.*;

// 상품 추가, 삭제
// 작업을 하려면 ADMIN 권한이 필요하므로 작성자 아이디를 확인하지 않는다
@Secured("ROLE_ADMIN")
@Controller
public class ProductAdminController {
	@Autowired
	private ProductService service;
	
	@GetMapping("/product/add")
	public void add() {
	}
	
	// J-011. 상품 추가
	@PostMapping("/product/add")
	public ModelAndView add(ProductDto.Create dto) {
		service.add(dto);
		return new ModelAndView("redirect:/");
	}
	
	// J-012. 상품 삭제
	@PostMapping("/product/delete")
	public ModelAndView delete(Long pno) {
		service.delete(pno);
		return new ModelAndView("redirect:/");
	}
}
