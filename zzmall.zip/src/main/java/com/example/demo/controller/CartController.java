package com.example.demo.controller;

import java.security.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.access.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.mvc.support.*;

import com.example.demo.dto.*;
import com.example.demo.service.*;

@Secured("ROLE_USER")
@Controller
public class CartController {
	@Autowired
	private CartService service;
	
	// J-031. 로그인한 사용자의 장바구니를 출력
	@GetMapping("/cart/read")
	public ModelAndView read(Principal principal) {
		CartDto.Read dto = service.read(principal.getName());
		return new ModelAndView("cart/read").addObject("dto", dto);
	}	
	
	// J-032. 로그인 아이디와 상품 번호로 장바구니에 상품 추가 
	@PostMapping("/cart/add")
	public ModelAndView add(Long pno, Principal principal) {
		service.add(pno, principal.getName());
		return new ModelAndView("redirect:/cart/read");
	}
	
	// J-033. 상품 개수 증가 : (장바구니 번호, 상품 번호(상품 재고량 확인), 로그인 아이디, RedirectAttribute)
	//    RedirectAttribute는 redirect 후 오류 메시지를 출력하기 위해 사용한다
	@PostMapping("/cart/increase")
	public ModelAndView increase(Long cno, Long pno, Principal principal, RedirectAttributes ra) {
		Boolean result = service.increase(cno, pno, principal.getName());
		// 재고량이 모자란 경우 result가 false
		if(result==false) 
			ra.addFlashAttribute("msg", "더 이상 담을 수 없습니다");
		return new ModelAndView("redirect:/cart/read");
	}
	
	// J-034. 상품 개수 감소 : (장바구니 번호, 로그인 아이디, RedirectAttribute)
	@PostMapping("/cart/decrease")
	public ModelAndView decrease(Long cno, Principal principal, RedirectAttributes ra) {
		Boolean result = service.decrease(cno, principal.getName());
		// 상품의 개수가 1이하인 경우 감소시킬 수 없다
		if(result==false)
			ra.addFlashAttribute("msg", "최소 1개이상부터 구입가능합니다");
		return new ModelAndView("redirect:/cart/read");
	}
	
	// J-035. 장바구니 상품 삭제 : (장바구니 번호 List, 로그인 아이디)
	//    장바구니에서 상품을 삭제하는 방법은 하나 또는 여러개
	//    둘 다 처리하기 위해서 장바구니 번호를 List<Long>으로 받아온다
	@PostMapping("/cart/delete")
	public ModelAndView delete(CartDto.Delete dto, Principal principal) {
		service.delete(dto, principal.getName());
		return new ModelAndView("redirect:/cart/read");
	}
}
