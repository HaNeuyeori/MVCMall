package com.example.demo.controller;

import java.io.*;
import java.nio.file.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.mvc.support.*;

import com.example.demo.dto.*;
import com.example.demo.service.*;

@Controller
public class ProductController {
	@Autowired
	private ProductService service;
	
	// J-013. 상품 목록 겸 루트 페이지
	@GetMapping({"/", "/product/list"})
	public ModelAndView index(@RequestParam(defaultValue="1") Long pageno) {
		Page page = service.list(pageno);
		return new ModelAndView("index").addObject("page", page);
	}
	
	// J-014. 상품 정보 출력
	@GetMapping("/product/read")
	public ModelAndView read(Long pno, RedirectAttributes ra) {
		ProductDto.Read dto = service.read(pno);
		// 상품 정보를 찾을 수 없다면 /로 이동한 후 오류메시지를 출력
		if(dto==null) {
			ra.addFlashAttribute("msg", "현재 판매중인 상품이 아닙니다");
			return new ModelAndView("redirect:/");
		}
		return new ModelAndView("product/read").addObject("dto", dto);
	}
	
	@GetMapping("/images/{imageName}")
	public ResponseEntity<byte[]> viewProfile(@PathVariable String imageName) {
	  File file = new File("c:/upload/image", imageName);
	  try {
		byte[] bytes = Files.readAllBytes(file.toPath());
		String contentType = Files.probeContentType(file.toPath()); 
		MediaType type = MediaType.parseMediaType(contentType);
		return ResponseEntity.ok().contentType(type).body(bytes);
	  } catch(Exception e) {
		  e.printStackTrace();
	  }
	  return null;
	}
}
