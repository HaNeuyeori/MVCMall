package com.example.demo.controller; 

import java.security.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.access.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

import com.example.demo.entity.*;
import com.example.demo.service.*;

@Secured("ROLE_USER")
@Controller
public class ReviewController {
	@Autowired
	private ReviewService service;
	
	// J-021. 리뷰 추가 : 리뷰와 로그인 아이디
	@PostMapping("/review/create")
	public ModelAndView create(Review review, Principal principal) {
		service.create(review, principal.getName());
		return new ModelAndView("redirect:/product/read?pno=" + review.getPno());
	}
	
	// J-022. 리뷰 삭제 : 리뷰와 로그인 아이디(작성자 여부 확인)
	@PostMapping("/review/delete")
	public ModelAndView delete(Long rno, Long pno, Principal principal) {
		service.delete(rno, pno, principal.getName());
		return new ModelAndView("redirect:/product/read?pno=" + pno);
	}
}
