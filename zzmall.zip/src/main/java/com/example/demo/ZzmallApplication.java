package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.*;

//스프링 스케줄러 활성화
@EnableScheduling
@SpringBootApplication
public class ZzmallApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZzmallApplication.class, args);
	}

}
