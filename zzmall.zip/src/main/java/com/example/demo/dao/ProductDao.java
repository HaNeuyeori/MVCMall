package com.example.demo.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.entity.*;

@Mapper
public interface ProductDao {
	public List<Product> findAll(Long startRownum, Long endRownum);
	
	public Long save(Product product);
	
	@Select("select count(*) from product")
	public Long count();

	@Select("select * from product where pno=#{pno} and rownum=1")
	public Product findById(Long pno);
	
	@Delete("delete from product where pno=#{pno}")
	public Integer deleteById(Long pno);

	// 장바구니 상품 개수를 증가할 때 재고량을 확인하기 위해 사용한다
	@Select("select stock from product where pno=#{pno} and rownum=1")
	public Long findStockById(Long pno);
}
