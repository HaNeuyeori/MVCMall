package com.example.demo.dto;

import java.time.*;

import org.springframework.format.annotation.*;
import org.springframework.web.multipart.*;

import com.example.demo.entity.*;

import lombok.*;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class MemberDto {
	@Data
	public static class Join {
		private String username;
		private String password;
		private String email;
		@DateTimeFormat(pattern="yyyy-MM-dd")
		private LocalDate birthday;
		private MultipartFile profile;
		
		public Member toEntity(String pname, String pwd) {
			return new Member(username,pwd,email,birthday,LocalDate.now(),pname,"USER");
		}
	}
	
	@Data
	@AllArgsConstructor
	public static class Read {
		private String username;
		private String email;
		private String birthday;
		private String joinday;
		private Long days;
		private String profile;	
	}
}
