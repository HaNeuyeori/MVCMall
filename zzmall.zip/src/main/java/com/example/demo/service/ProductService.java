package com.example.demo.service;

import java.io.*;
import java.util.*;

import org.apache.commons.io.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.multipart.*;

import com.example.demo.dao.*;
import com.example.demo.dto.*;
import com.example.demo.entity.*;

@Service
public class ProductService {
	@Autowired
	private ProductDao productDao;
	@Autowired
	private ImageDao imageDao;
	@Autowired
	private ReviewDao reviewDao;
	
	@Value("${numberOfProductsPerPage}")
	private Long numberOfProductsPerPage;
	@Value("${sizeOfPagination}")
	private Long sizeOfPagination;
	@Value("${imageFolder}")
	private String imageFolder;
	@Value("${imageUrl}")
	private String imageUrl;
	
	public void add(ProductDto.Create dto) {
		Product p = new Product(null, dto.getVendor(), dto.getName(), dto.getInfo(), 0L, 0L, dto.getStock(), dto.getPrice());
		productDao.save(p);
		for(MultipartFile i:dto.getImages()) {
			if(i.isEmpty()==false) {
				// db에 저장한 이름은 주소를 포함, 디스크의 파일명은 주소를 포함하면 안된다
				// 주소없는 이름으로 파일을 먼저 저장
				String name = UUID.randomUUID()+ "." + FilenameUtils.getExtension(i.getOriginalFilename());
				File file = new File(imageFolder, name);
				try {
					i.transferTo(file);
				} catch (IllegalStateException | IOException e) {
					e.printStackTrace();
				}
				// 주소를 붙인 이름을 db에 저장
				Image image = new Image(null, imageUrl + name, p.getPno());
				imageDao.save(image);
			}
		}
	}
	
	public void delete(Long pno) {
		reviewDao.deleteByPno(pno);
		imageDao.deleteByPno(pno);
		productDao.deleteById(pno);
	}
	
	// pageno, 개수 -> prev, start, end, next, pageno, 제품들을 출력한다
	public Page list(Long pageno) {
		Long count = productDao.count();
		Long numberOfPage = (count-1)/numberOfProductsPerPage + 1;
		
		Long startRownum = (pageno-1)*numberOfProductsPerPage + 1;
		Long endRownum = pageno * numberOfProductsPerPage;
		List<Product> products = productDao.findAll(startRownum, endRownum);
		
		Long start = (pageno-1)/sizeOfPagination * sizeOfPagination + 1;
		Long prev = start - 1;
		Long end = prev + sizeOfPagination;
		Long next = end + 1;
		
		// end가 numberOfPage보다 같거나 크다면...처리
		if(end>=numberOfPage) {
			end = numberOfPage;
			next = 0L;
		}		
		return new Page(prev, start, end, next, pageno, products);
	}

	// 상품, 이미지들, 리뷰들, 리뷰 개수, 리뷰 평점 평균을 읽어 출력
	public ProductDto.Read read(Long pno) {
		Product p = productDao.findById(pno);
		if(p==null)
			return null;
		List<String> images = imageDao.findByPno(pno);
		// 사진이 한장도 없다면 default.jpg를 출력
		if(images.size()==0)
			images = Arrays.asList(imageUrl + "default.jpg");
		List<Review> reviews = reviewDao.findByPno(pno);
		Long countOfReview = reviewDao.countByPno(pno);
		Double avgOfReview = reviewDao.avgByPno(pno);
		return new ProductDto.Read(p.getPno(), p.getVendor(), p.getName(), p.getInfo(),p.getPrice(), countOfReview, avgOfReview, images, reviews);
	}
}

