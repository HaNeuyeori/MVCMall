package com.example.demo.service;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;

import com.example.demo.dao.*;
import com.example.demo.dto.*;
import com.example.demo.entity.*;

@Service
public class CartService {
	@Autowired
	private CartDao cartDao;
	@Autowired
	private ImageDao imageDao;
	@Autowired
	private ProductDao productDao;

	// 장바구니 목록과 가격 합계를 CartDto.Read에 담아 리턴
	@Transactional(readOnly=true)
	public CartDto.Read read(String loginId) {
		List<Cart> carts = cartDao.findByUsername(loginId);
		Long totalPrice = cartDao.sumByUsername(loginId);
		return new CartDto.Read(carts, totalPrice);
	}

	// 장바구니에 있는 상품이면 개수 증가, 없는 상품이면 담는다
	public Boolean add(Long pno, String loginId) {
		// 장바구니 번호를 모르므로 로그인 아이디와 상품 번호로 장바구니에서 찾는다
		Cart cart = cartDao.findByUsernameAndPno(pno, loginId);
		if(cart!=null) {
			// 있으면 개수 증가
			Long stock = productDao.findStockById(pno);
			if(cart.getCount()>=stock)
				return false;
			return cartDao.increase(cart.getCno(), loginId)==1;
		}
		else {
			// 없으면 상품 추가
			String image = imageDao.findByPno(pno).get(0);
			Product product = productDao.findById(pno);
			Cart newCart = new Cart(null, loginId, pno, image, loginId, 1L, product.getPrice(), product.getPrice());
			return cartDao.add(newCart)==1;
		}
	}

	// 장바구니 개수 증가
	public Boolean increase(Long cno, Long pno, String loginId) {
		Long stock = productDao.findStockById(pno);
		Cart cart = cartDao.findById(cno);
		if(cart.getCount()>=stock)
			return false;
		return cartDao.increase(cno, loginId)==1;
	}

	// 장바구니 개수 감소
	public Boolean decrease(Long cno, String loginId) {
		Cart cart = cartDao.findById(cno);
		if(cart.getCount()<=1)
			return false;
		return cartDao.decrease(cno, loginId)==1;
	}

	// 장바구니에서 삭제
	public void delete(CartDto.Delete dto, String loginId) {
		List<Long> cnos = dto.getCnos();
		for(Long cno:cnos) 
			cartDao.deleteByIdAndUsername(cno, loginId);
	}

}
