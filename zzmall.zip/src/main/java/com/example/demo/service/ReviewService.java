package com.example.demo.service;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.example.demo.dao.*;
import com.example.demo.entity.*;

@Service
public class ReviewService {
	@Autowired
	private ReviewDao reviewDao;
	
	// 글쓴이를 추가해서 리뷰 저장
	public void create(Review review, String loginId) {
		review.setWriter(loginId);
		reviewDao.save(review);
	}

	// 글쓴이와 리뷰번호로 리뷰 삭제 -> 글쓴이가 다를 경우 삭제되지 않음
	public void delete(Long rno, Long pno, String loginId) {
		reviewDao.deleteByIdAndWriter(rno, loginId);
	}
}
