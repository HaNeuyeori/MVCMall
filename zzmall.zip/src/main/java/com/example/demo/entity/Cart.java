package com.example.demo.entity;

import lombok.*;

@Data
@AllArgsConstructor
public class Cart {
	private Long cno;
	private String username;
	private Long pno;
	private String image;
	private String name;
	private Long count;
	private Long price;
	private Long cartPrice;
}