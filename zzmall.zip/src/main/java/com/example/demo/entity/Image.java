package com.example.demo.entity;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Image {
	private Long ino;
	private String name;
	private Long pno;
}
