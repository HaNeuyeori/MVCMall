package com.example.demo;

import java.util.*;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;

import com.example.demo.dao.*;
import com.example.demo.dto.*;
import com.example.demo.entity.*;
import com.example.demo.service.*;

@SpringBootTest
public class ProductTest {
  @Autowired
  private ProductDao productDao;
  @Autowired
  private ProductService service;
  
  @Test
  public void saveTest() {
    for(int i=1; i<=123; i++) {
      Product p = new Product(null,"롯데",i+"번째 상품",i+"번째 내용",
                  0L,0L,10L,100000L);
      productDao.save(p);
    }
  }
  
//  @Test
  public void pagingTest1() {
//    한 페이지당 상품의 개수는 10개
    Long pageno = 2L;
//    페이지 번호의 범위 : 1~페이지의 개수
    Long count = productDao.count();
    Long numberOfPage = (count-1)/10+1;
    
//    11~20번까지 product 읽어오기
    Long startRownum = (pageno-1)*10+1;
    Long endRownum = pageno*10;
    List<Product> products = productDao.findAll(startRownum, endRownum);
    
//    prev, start, end, next 계산
//    pageno  prev  start end     next
//    1~5     0     1     5       6
//    6~10    5     6     10      11
//    11~15   10    11    15=>13  16=>0
    Long prev = (pageno-1)/5*5;
    Long start = prev+1;
    Long end = prev+5;
    Long next = end+1;
    
    if(end>=numberOfPage) {
      end=numberOfPage;
      next=0L;
    }
    System.out.println(new Page(prev, start, end, next, pageno, products));
  }
  
//  @Test
  public void pagingTest() {
    /*
     * i
     * 1~5  0   1   5   6   pageno  products
     * 6~10 5   6   10  11  pageno  products
     * 11+  10  11  13  0   pageno  products
     */
    for(long i=1; i<=15; i++) {
      System.out.println(service.list(i));
    }
  }
}
