package com.example.demo;

import java.time.*;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.security.crypto.password.*;

import com.example.demo.dao.*;
import com.example.demo.entity.*;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class MybatisMallApplicationTests {
	@Autowired
	PasswordEncoder encoder;
	@Autowired
	MemberDao memberDao;

	//@Test
	public void saveTest() {
		String pwd = encoder.encode("1234");
		Member m=new Member("spring",pwd,"s@naver.com",LocalDate.of(2000, 1, 1), 
				LocalDate.now(), "default.png", "USER"); 
		assertEquals(1, memberDao.save(m));
	}
	
	//@Test
	public void findByIdTest() {
		Member m = memberDao.findById("spring");
		System.out.println(m);
		assertNotNull(m);
	}
	
	@Test
	public void aaa() {
		System.out.println(encoder.encode("1234"));
	}

}





