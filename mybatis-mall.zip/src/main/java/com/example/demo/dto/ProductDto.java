package com.example.demo.dto;

import java.util.*;

import org.springframework.web.multipart.*;

import lombok.*;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class ProductDto {
  @Data
  public static class Create {
    private String vendor;
    private String name;
    private String info;
    private Long stock;
    private Long price;
    private List<MultipartFile> images;
  }
  
  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Read {
    private Long pno;
    private String vendor;
    private String name;
    private String info;
    private Long price;
    private Long reviewCount;
    private Double reviewStar;
    private List<String> images;
  }
}
