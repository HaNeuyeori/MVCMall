package com.example.demo.controller;

import java.io.*;
import java.nio.file.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.mvc.support.*;

import com.example.demo.dto.*;
import com.example.demo.service.*;

@Controller
public class ProductController {
  @Autowired
  private ProductService service;

  @GetMapping({ "/", "/product/list" })
  public ModelAndView index(@RequestParam(defaultValue = "1") Long pageno) {
//		@PathVariable 은 기본값 설정을 하지 못한다.
    Page page = service.list(pageno);
    return new ModelAndView("index").addObject("page", page);
  }

  @GetMapping("/product/read")
  public ModelAndView read(@RequestParam(required = false) Long pno, RedirectAttributes ra) {
//	  상품 정보를 찾을 수 없다면 /로 이동한 후 에러 메시지를 띄우자.
    if (pno == null) {
      ra.addFlashAttribute("msg", "잘못된 요청입니다.");
      return new ModelAndView("redirect:/");
    }
    ProductDto.Read dto = service.read(pno);
    if (dto == null) {
      ra.addFlashAttribute("msg", "상품을 찾을 수 없습니다.");
      return new ModelAndView("redirect:/");
    }
    return new ModelAndView("product/read").addObject("dto", dto);
  }

  @GetMapping("/images/{imageName}")
  public ResponseEntity<byte[]> view(@PathVariable String imageName) {
    File file = new File("c:/upload/image/", imageName);
    try {
      byte[] bytes = Files.readAllBytes(file.toPath());

      String contentType = Files.probeContentType(file.toPath());

      MediaType type = MediaType.parseMediaType(contentType);
      return ResponseEntity.ok().contentType(type).body(bytes);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }
}
