package com.example.demo.controller;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.access.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

import com.example.demo.dto.*;
import com.example.demo.service.*;

// 상품 추가, 삭제
@Secured("ROLE_ADMIN")
@Controller
public class ProductAdminController {
  @Autowired
  private ProductService service;
  
  @GetMapping("/product/add")
  public ModelAndView add() {
    return new ModelAndView("product/add");
  }

  // J-011. 상품 추가
  @PostMapping("/product/add")
  public ModelAndView add(@ModelAttribute ProductDto.Create dto) {
    service.addProduct(dto);
    return new ModelAndView("redirect:/");
  }
  
  // J-012. 상품 삭제
  @PostMapping("/product/delete")
  public ModelAndView delete(Long pno) {
	service.deleteProduct(pno);
    return new ModelAndView("redirect:/");
  }
}




