package com.example.demo.sample;

import org.springframework.http.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

import lombok.*;

@Data
class Sample {
  private String id;
  private String pwd;
}

@Controller
public class SampleController {
  @PostMapping("/sample001")
  public ResponseEntity<Void> sample001(Sample sample) {
    System.out.println(sample);
    return ResponseEntity.ok(null);
  }
  
  @PostMapping("/sample002")
  public ResponseEntity<Void> sample002(Sample sample) {
    System.out.println(sample);
    return ResponseEntity.ok(null);
  }
  
  @PostMapping("/sample003")
  public ResponseEntity<Void> sample003(@RequestBody Sample sample) {
    System.out.println(sample);
    return ResponseEntity.ok(null);
  }
}
