package com.example.demo.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.entity.*;

@Mapper
public interface ProductDao {
  public List<Product> findAll(Long startRownum, Long endRownum);

  public Long save(Product product);
  
  @Select("select count(*) from product")
  public Long count();

  @Select("select * from product where pno=#{pno} and rownum=1")
  public Product findById(Long pno);

  @Delete("delete from product where pno=#{pno}")
  public void deleteById(Long pno);
}
