package com.example.demo.service;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.password.*;
import org.springframework.stereotype.*;

import com.example.demo.dao.*;
import com.example.demo.entity.*;

@Component
public class MyUserDetailsService implements UserDetailsService {
	@Autowired
	private MemberDao memberDao;
	@Autowired
	private PasswordEncoder encoder;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// 관리자 계정이 admin/1234라고 하자
		// admin 로그인이 아닌 경우 db에서 사용자 정보를 읽어 리턴
		// admin 로그인인 경우 admin, 1234, ADMIN 정보를 리턴
		if(username.equals("admin"))
			return User.builder().username("admin").password(encoder.encode("1234"))
				.roles("ADMIN").build();
		Member m = memberDao.findById(username);
		if(m==null)
			throw new UsernameNotFoundException("");
		return User.builder().username(username).password(m.getPassword())
				.roles(m.getRoles()).build();
	}

}
