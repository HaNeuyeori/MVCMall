 package com.example.demo.service;

import java.io.*;
import java.util.*;

import org.apache.commons.io.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.multipart.*;

import com.example.demo.dao.*;
import com.example.demo.dto.*;
import com.example.demo.entity.*;

@Service
public class ProductService {
  @Autowired
  private ProductDao productDao;
  @Autowired
  private ImageDao imageDao;
  @Value("${numberOfProductsPerPage}")
  private Long numberOfProductsPerPage;
  @Value("${sizeOfPagination}")
  private Long sizeOfPagination;
  @Value("${imageFolder}")
  private String imageFolder;
  @Value("${imageUrl}")
  private String imageUrl;
  
  public void addProduct(ProductDto.Create dto) {
	// 상품 저장 -> 이미지 이름 변경 -> pno로 저장
	Product p = new Product(null, dto.getVendor(), dto.getName(), dto.getInfo(), 0L, 0L, dto.getStock(), dto.getPrice());  
	productDao.save(p);
	
	for(MultipartFile i:dto.getImages()) {
		if(i.isEmpty()==false) {
		  String name =  UUID.randomUUID()+ "." 
		    + FilenameUtils.getExtension(i.getOriginalFilename());
		  File file = new File(imageFolder, name);
		  try {
			i.transferTo(file);
			Image image = new Image(null, imageUrl + name, p.getPno());
			imageDao.save(image);
		  } catch (IllegalStateException | IOException e) {
			  e.printStackTrace();
		  } 
		}
	}
  }

  public void deleteProduct(Long pno) {
	imageDao.deleteByPno(pno);
	productDao.deleteById(pno);  
  }
  
  public Page list(Long pageno) {
    Long count = productDao.count();
    Long numberOfPage = (count-1)/numberOfProductsPerPage+1;
    
    if(pageno<0)
      pageno=-pageno;
    else if(pageno==0)
      pageno=1L;
    else if(pageno>numberOfPage)
      pageno=numberOfPage;
    
    Long startRownum = (pageno-1)*numberOfProductsPerPage+1;
    Long endRownum = pageno*numberOfProductsPerPage;
    List<Product> products = productDao.findAll(startRownum, endRownum);
    
    
    Long start = (pageno-1)/sizeOfPagination*sizeOfPagination+1;
    Long prev = start-1;
    Long end = prev+sizeOfPagination;
    Long next = end+1;
    
    if(end>=numberOfPage) {
      end=numberOfPage;
      next=0L;
    }
    return new Page(prev, start, end, next, pageno, products);
  }
  

 
//  123.jpg => localhost:8081/profiles/spring.jsp
  public ProductDto.Read read(Long pno) {
    Product p = productDao.findById(pno);
    if(p==null) 
      return null;
    List<String> images = imageDao.findByPno(pno);
//    사진이 한 장도 없으면 default.jpg 를 출력
    if(images.size()==0)
      images = Arrays.asList(imageUrl + "default.jpg");
    ProductDto.Read dto =
        new ProductDto.Read(p.getPno(),
            p.getVendor(), p.getName(),
            p.getInfo(), p.getPrice(),
            0L, 0.0, images);
    return dto;
  }
}
