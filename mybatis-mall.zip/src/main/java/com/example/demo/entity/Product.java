package com.example.demo.entity;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product {
  private Long pno;
  private String vendor;
  private String name;
  private String info;
  private Long salesCount;
  private Long salesAmount;
  private Long stock;
  private Long price;
}
