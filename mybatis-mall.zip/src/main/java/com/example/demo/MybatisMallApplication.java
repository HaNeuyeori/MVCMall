package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.*;

@EnableScheduling
@SpringBootApplication
public class MybatisMallApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybatisMallApplication.class, args);
	}

}
